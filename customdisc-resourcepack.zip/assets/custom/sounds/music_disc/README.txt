Place your .ogg files in this folder, for example:

- sunrise_groove.ogg
- cave_echoes.ogg

Those paths correspond to the example sounds.json entries:

- custom:music_disc/sunrise_groove
- custom:music_disc/cave_echoes
